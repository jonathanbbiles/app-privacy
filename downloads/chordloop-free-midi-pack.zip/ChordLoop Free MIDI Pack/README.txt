CHORDLOOP FREE MIDI PACK
========================

40 chord progressions as MIDI files, for producers and songwriters. Pop, ballad, R&B,
lo-fi and cinematic. Every file is in C major or A minor, so you can drop it in and
transpose it to any key in your DAW with one move.

WHAT IS IN THE FOLDER

Chords/  One file per progression. The chords are held for their full length and voiced
as inversions, so each chord moves to the next by the smallest step. That keeps them
smooth on a piano, a pad or strings.
Bass/    The same progressions as a bass line: the root of each chord, or the bass note
of a slash chord. Put it on a bass or sub under the chords.
Every file has the tempo, 4/4, the key and a marker with each chord's name. File names
read: genre and number, key, Roman numerals, tempo.

READING THE NUMERALS

Upper case is a major chord (IV), lower case is minor (vi). A number after the numeral
is the chord's extension (V7, ii9). A b in front means the root is lowered (bVII). In
file names, an underscore marks a slash chord: V_7 is the V chord with the 7th note of
the scale in the bass, written V/7 below. 'dim' is diminished, 'm7b5' is
half-diminished.

HOW TO USE THEM

GarageBand: drag a file from Finder into the empty area under your tracks. It makes a
new software instrument track. Pick a piano or a pad.
Ableton Live: drag a file onto a MIDI track that has an instrument on it. Use the clip's
transpose control to change key.
FL Studio: drag a file into the Playlist or the Channel Rack. FL Studio puts the notes
in a pattern; give that channel a piano or pad plugin.
Logic Pro: drag a file into the tracks area. If Logic asks whether to import the file's
tempo, say yes to hear it at the written BPM.

THE PROGRESSIONS

POP
  Pop 01  The axis progression, 100 BPM
      C major | I | V | vi | IV |
      | C | G | Am | F |
  Pop 02  The axis, starting on vi, 118 BPM
      C major | vi | IV | I | V |
      | Am | F | C | G |
  Pop 03  The 50s progression, 96 BPM
      C major | I | vi | IV | V |
      | C | Am | F | G |
  Pop 04  I-IV-vi-V, 104 BPM
      C major | I | IV | vi | V |
      | C | F | Am | G |
  Pop 05  Start on IV, 112 BPM
      C major | IV | I | V | vi |
      | F | C | G | Am |
  Pop 06  Pachelbel's Canon, 90 BPM
      C major | I | V | vi | iii | IV | I | IV | V |
      | C | G | Am | Em | F | C | F | G |
  Pop 07  Walking the bass down to vi, 92 BPM
      C major | I | V/7 | vi | IV |
      | C | G/B | Am | F |
  Pop 08  Mixolydian flat VII, 116 BPM
      C major | I | bVII | IV | I |
      | C | Bb | F | C |

BALLAD
  Ballad 01  Bass climbs from 1 to 3, 72 BPM
      C major | I | I/3 | IV | V |
      | C | C/E | F | G |
  Ballad 02  Descending bass, eight bars, 70 BPM
      C major | I | V/7 | vi | vi/5 | IV | I/3 | ii | V |
      | C | G/B | Am | Am/G | F | C/E | Dm | G |
  Ballad 03  Borrowed minor iv, 68 BPM
      C major | I | IV | iv | I |
      | C | F | Fm | C |
  Ballad 04  I-vi-ii-V, 76 BPM
      C major | I | vi | ii | V |
      | C | Am | Dm | G |
  Ballad 05  The royal road, 74 BPM
      C major | IVmaj7 | V7 | iii7 | vi |
      | Fmaj7 | G7 | Em7 | Am |
  Ballad 06  Minor key with a major V, 66 BPM
      A minor | i | iv | VI | V |
      | Am | Dm | F | E |
  Ballad 07  IV down to I over 3, 70 BPM
      C major | IV | I/3 | ii | I |
      | F | C/E | Dm | C |
  Ballad 08  Major III and minor iv, 72 BPM
      C major | I | III | IV | iv |
      | C | E | F | Fm |

R&B
  RnB 01  R&B turnaround, 84 BPM
      C major | Imaj7 | vi7 | ii7 | V7 |
      | Cmaj7 | Am7 | Dm7 | G7 |
  RnB 02  Stepping down in 7ths, 78 BPM
      C major | IVmaj7 | iii7 | ii7 | Imaj7 |
      | Fmaj7 | Em7 | Dm7 | Cmaj7 |
  RnB 03  Just the Two of Us changes, 96 BPM
      C major | IVmaj7 | III7 | vi7 | v7 I7 |
      | Fmaj7 | E7 | Am7 | Gm7 C7 |
  RnB 04  6-2-5-1, 88 BPM
      C major | vi7 | ii7 | V7 | Imaj7 |
      | Am7 | Dm7 | G7 | Cmaj7 |
  RnB 05  IV to a borrowed iv6, 80 BPM
      C major | IVmaj7 | iv6 | iii7 | vi7 |
      | Fmaj7 | Fm6 | Em7 | Am7 |
  RnB 06  Minor 7ths climbing to VI, 86 BPM
      A minor | i7 | iv7 | v7 | VImaj7 |
      | Am7 | Dm7 | Em7 | Fmaj7 |
  RnB 07  ii-V, then iii-vi, 82 BPM
      C major | ii7 | V7 | iii7 | vi7 |
      | Dm7 | G7 | Em7 | Am7 |
  RnB 08  I to I7, IV to iv, 76 BPM
      C major | Imaj7 | I7 | IVmaj7 | iv7 |
      | Cmaj7 | C7 | Fmaj7 | Fm7 |

LO-FI
  Lo-fi 01  ii-V-I in 9ths, 78 BPM
      C major | ii9 | V13 | Imaj9 | Imaj9 |
      | Dm9 | G13 | Cmaj9 | Cmaj9 |
  Lo-fi 02  Two-chord minor 9th vamp, 74 BPM
      A minor | i9 | % | iv9 | % |
      | Am9 | % | Dm9 | % |
  Lo-fi 03  I-iii-IV-iv6, 72 BPM
      C major | Imaj7 | iii7 | IVmaj7 | iv6 |
      | Cmaj7 | Em7 | Fmaj7 | Fm6 |
  Lo-fi 04  Minor 7ths, starting on VI, 76 BPM
      A minor | VImaj7 | v7 | i7 | iv7 |
      | Fmaj7 | Em7 | Am7 | Dm7 |
  Lo-fi 05  ii-V, then iii-VI7, 82 BPM
      C major | ii9 | V13 | iii7 | VI7♭9 |
      | Dm9 | G13 | Em7 | A7b9 |
  Lo-fi 06  Imaj7 to IVmaj7 sway, 70 BPM
      C major | Imaj7 | % | IVmaj7 | % |
      | Cmaj7 | % | Fmaj7 | % |
  Lo-fi 07  Minor ii-V-i, 80 BPM
      A minor | iiø7 | V7♭9 | i9 | i9 |
      | Bm7b5 | E7b9 | Am9 | Am9 |
  Lo-fi 08  iii-VI7-ii-V7, 84 BPM
      C major | iii7 | VI7 | ii7 | V7 |
      | Em7 | A7 | Dm7 | G7 |

CINEMATIC
  Cinematic 01  The minor climb, 80 BPM
      A minor | i | iv | VI | VII |
      | Am | Dm | F | G |
  Cinematic 02  Andalusian cadence, 76 BPM
      A minor | i | VII | VI | V |
      | Am | G | F | E |
  Cinematic 03  Lament with a raised 6 in the bass, 66 BPM
      A minor | i | v/7 | IV/#6 | V |
      | Am | Em/G | D/F# | E |
  Cinematic 04  Neapolitan, 70 BPM
      A minor | i | bII | V | i |
      | Am | Bb | E | Am |
  Cinematic 05  Heroic bVI-bVII-I, 84 BPM
      C major | I | bVI | bVII | I |
      | C | Ab | Bb | C |
  Cinematic 06  Rise to the tonic, 72 BPM
      A minor | VI | VII | i | i |
      | F | G | Am | Am |
  Cinematic 07  Minor line cliche, 68 BPM
      A minor | i | i(maj7) | i7 | i6 |
      | Am | Am(maj7) | Am7 | Am6 |
  Cinematic 08  i-VI-iv with a suspended V, 74 BPM
      A minor | i | VI | iv | Vsus4 V |
      | Am | F | Dm | Esus4 E |

HEAR AND EDIT THEM FIRST

This pack comes from ChordLoop, an iPhone app by the same maker. In ChordLoop you can
hear and loop a progression, change its key, tempo and sound, try 7ths, then export it
as MIDI. Hear and edit any progression before you drag it in:
https://apps.apple.com/app/apple-store/id6787716007?pt=129125244&ct=midi-readme&mt=8

MORE PACKS

Four bigger packs, each with 60 progressions in all 12 keys, chords and bass (1,440 MIDI
files), same license:
  Neo-Soul & Jazz ($15): https://misterhoneywood.gumroad.com/l/neo-soul-midi
  Lo-fi & Chill R&B ($12): https://misterhoneywood.gumroad.com/l/lofi-midi
  Cinematic & Emotional ($12): https://misterhoneywood.gumroad.com/l/cinematic-midi
  Pop & Dance ($9): https://misterhoneywood.gumroad.com/l/pop-midi

LICENSE

Royalty-free for your own music, commercial releases included. Do not resell or share
the MIDI files themselves as a pack. Full terms in LICENSE.txt.

Made by Jonathan Biles. Questions: jonathanbbiles@gmail.com
